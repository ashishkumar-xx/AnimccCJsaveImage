(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(1,1,1).p("ALrAAQAAFjjbD6QjbD8k1AAQk0AAjbj8Qjbj6AAljQAAliDbj7QDbj7E0AAQE1AADbD7QDbD7AAFig");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-75.6,-86.6,151.3,173.3);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#333333").ss(1,1,1).p("ALrAAQAAFjjbD6QjbD8k1AAQk0AAjbj8Qjbj6AAljQAAliDbj7QDbj7E0AAQE1AADbD7QDbD7AAFig");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-75.6,-86.6,151.3,173.3);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ai4AuQgLgJgCgSIAVgDQACALAGAFQAGAFAKAAQAKAAAGgFQAFgEAAgGQAAgDgCgDQgDgDgFgCIgSgFQgRgEgHgFQgKgJAAgMQAAgJAFgHQAEgHAJgEQAJgEAMAAQAUAAALAJQAKAJAAAPIgVABQgCgIgEgEQgFgEgJAAQgJAAgGAEQgDADAAAEQAAADADADQAEAEAQADQAQAEAHAEQAIAEAEAGQAEAHAAAKQAAAJgFAIQgFAJgJADQgKAFgOAAQgUAAgLgKgAB0A2IAAhrIBQAAIAAATIg6AAIAAAXIA2AAIAAARIg2AAIAAAeIA8AAIAAASgAAsA2IgnhrIAYAAIAbBOIAahOIAXAAIgmBrgAgSA2IgJgZIgrAAIgJAZIgXAAIAqhrIAWAAIAqBrgAhAALIAeAAIgPgng");
	this.shape.setTransform(-4.7,-3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AnLCFIAAkJIOXAAIAAEJg");
	this.shape_1.setTransform(0.7,-3);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-45.3,-16.3,92,26.6);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(85.7,85.7);

	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(85.7,91.7,0.009,0.008,0,0,180);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true,scaleX:0.01,scaleY:0.01,skewY:180,y:91.7},24).to({_off:false,scaleX:1,scaleY:0.69,skewY:0,y:112.7},25).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:false},24).to({_off:true,scaleX:1,scaleY:0.69,skewY:0,y:112.7},25).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(10,-1,151.3,173.3);


(lib.finalObject = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.Symbol3();
	this.instance.parent = this;
	this.instance.setTransform(112.3,121.3,1,1,0,0,0,74.7,85.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 1
	this.text = new cjs.Text("ART WORK", "bold 18px 'Arial'", "#FFFFFF");
	this.text.lineHeight = 22;
	this.text.lineWidth = 106;
	this.text.parent = this;
	this.text.setTransform(67.5,105.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FF0000","#FFFF00","#00FF00","#00FFFF","#0000FF","#FF00FF","#FF0000"],[0,0.165,0.365,0.498,0.667,0.831,1],-125,0,125,0).s().p("AtzN0QlulvAAoFQAAoEFulvQFvluIEAAQIFAAFvFuQFuFvAAIEQAAIFluFvQlvFuoFAAQoEAAlvlug");
	this.shape.setTransform(125,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.finalObject, new cjs.Rectangle(0,0,250,250), null);


// stage content:
(lib.savemcasimage = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/*
		version 1.0
		By- ashishkummar@gmail.com
		Save / download image
		*/
		
		this.saveBtn.addEventListener("click", fl_ClickedSaveBtn);
		
		var obj = this.finalObject;
		var timeLine = this;
		var fileNameCounter=1;
		
		function fl_ClickedSaveBtn() {
		 saveMCtoImage(obj)
		}
		
		 
		function saveMCtoImage(_movieClipName) {
			
		var pt = _movieClipName.localToLocal(0, 0, timeLine);
		var ctx = canvas.getContext('2d');
		var imagedata = ctx.getImageData(pt.x, pt.y, _movieClipName.nominalBounds.width, _movieClipName.nominalBounds.height) ;	
		
			var newCan = document.createElement("canvas");
				newCan.width=_movieClipName.nominalBounds.width;
				newCan.height=_movieClipName.nominalBounds.height;
		 	
			
			var newCanctx = newCan.getContext('2d');
			    newCanctx.putImageData(imagedata,0,0);
			
			
		    var b64  = newCan.toDataURL("#FFFFFF", "image/png");
			var aTag = document.createElement('a');
			aTag.download = 'artwork'+fileNameCounter;
			 aTag.href = b64
			 aTag.click();
			fileNameCounter++; 
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 2
	this.finalObject = new lib.finalObject();
	this.finalObject.parent = this;
	this.finalObject.setTransform(232.3,126.4,1,1,0,0,0,82.3,89.3);

	this.timeline.addTween(cjs.Tween.get(this.finalObject).wait(1));

	// Layer 1
	this.saveBtn = new lib.Symbol1();
	this.saveBtn.parent = this;
	this.saveBtn.setTransform(274.3,336.8);
	new cjs.ButtonHelper(this.saveBtn, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.saveBtn).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(425,237.1,250,310);
// library properties:
lib.properties = {
	width: 550,
	height: 400,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;